package com.jason.versions

object AppConfig{

    val compileSdkVersion = 29
    val buildToolsVersion = "29.0.3"
    val minSdkVersion = 21
    val targetSdkVersion = 29
    val versionCode = 12
    val versionName = "1.0"

}