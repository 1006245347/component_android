package com.jason.versions

import org.gradle.api.Plugin
import org.gradle.api.Project

/**
 * @author by jason-何伟杰，2021/4/26
 * des:
 */
class VersionPlugin : Plugin<Project> {
    override fun apply(project: Project) {
    }

    companion object {
    }
}