package com.jason.versions

/**
 * @author by jason-何伟杰，2021/4/26
 * des:所有依赖的版本号
 */
object Versions {
    val isDebug = true  //true那么module可单独运行
    val retrofit = "2.9.0"
    val appcompat = "1.2.0"
    val coreKtx = "1.3.1"//1.3.1
    val constraintlayout = "2.0.4" //1.1.3
    val kotlin = "1.4.10"
    val room = "2.3.0"
    val work = "2.3.4"

    val junit = "4.12"
    val junitExt = "1.1.1"
    val espressoCore = "3.2.0"
    val lifecycle = "2.2.0"
    val smartlayout = "2.0.1"
    val rvhelper = "3.0.4"
    val immersionbar = "3.0.0"
    val eventbus = "3.2.0"
    val glide = "4.11.0"
    val glideTrans = "4.3.0"
    val crashUpdate = "1.4.2"
    val lottie = "3.4.2"
    val arouter = "1.5.1"
    val arouterNote = "1.5.1"
    val agentweb = "4.1.4"
}

/**
 * @author by jason-何伟杰，2021/4/26
 * des:依赖分组
 */
object AndroidX {
    val appcompat = "androidx.appcompat:appcompat:${Versions.appcompat}"
    val material = "com.google.android.material:material:${Versions.appcompat}"
    val constraintLayout = "androidx.constraintlayout:constraintlayout:${Versions.constraintlayout}"
    val lifecycle_ex = "androidx.lifecycle:lifecycle-extensions:${Versions.lifecycle}"
    val lifecycle_vm = "androidx.lifecycle:lifecycle-viewmodel-ktx:${Versions.lifecycle}"
    val lifecycle_ld = "androidx.lifecycle:lifecycle-livedata-ktx:${Versions.lifecycle}"
    val lifecycle_core = "androidx.lifecycle:lifecycle-runtime-ktx:${Versions.lifecycle}"
}

object Room {
    val runtime = "androidx.room:room-runtime:${Versions.room}"
    val compiler = "androidx.room:room-compiler:${Versions.room}"
    val ktx = "androidx.room:room-ktx:${Versions.room}"
}

object Work {
    // Kotlin + coroutines
    val runtime = "androidx.work:work-runtime-ktx:${Versions.work}"

    // optional - GCMNetworkManager support
    val gcm = "androidx.work:work-gcm:${Versions.work}"
}

object Kt {
    val coreKtx = "androidx.core:core-ktx:${Versions.coreKtx}"
    val stdlibJdk7 = "org.jetbrains.kotlin:kotlin-stdlib-jdk7:${Versions.kotlin}"
    val plugin = "org.jetbrains.kotlin:kotlin-gradle-plugin:${Versions.kotlin}"
}

object Depend {
    val junit = "junit:junit:${Versions.junit}"
    val androidTestJunit = "androidx.test.ext:junit:${Versions.junitExt}"
    val espressoCore = "androidx.test.espresso:espresso-core:${Versions.espressoCore}"
}

object HTTP {
    val core = "com.squareup.retrofit2:retrofit:${Versions.retrofit}"
    val gson = "com.squareup.retrofit2:converter-gson:${Versions.retrofit}"

}

object WIDGET {
    val rvhelper = "com.github.CymChad:BaseRecyclerViewAdapterHelper:${Versions.rvhelper}"

    //https://github.com/gyf-dev/ImmersionBar
    val immersionbar = "com.gyf.immersionbar:immersionbar:${Versions.immersionbar}"

    //核心必须依赖 https://github.com/scwang90/SmartRefreshLayout/blob/master/art/md_property.md
    val smartCore = "com.scwang.smart:refresh-layout-kernel:${Versions.smartlayout}"
    val smartHead = "com.scwang.smart:refresh-header-classics:${Versions.smartlayout}"    //经典刷新头
    val smartFoot = "com.scwang.smart:refresh-footer-classics:${Versions.smartlayout}"    //经典加载

    val webviewCore = "com.just.agentweb:agentweb-androidx:${Versions.agentweb}"
    val webviewFile = "com.just.agentweb:filechooser-androidx:${Versions.agentweb}"
    val webviewDownload = "com.download.library:downloader-androidx:${Versions.agentweb}"
    val lottie = "com.airbnb.android:lottie:${Versions.lottie}"
}

object Funtion {
    val mmkv = "com.tencent:mmkv:1.0.22"
    val multidex = "androidx.multidex:multidex:2.0.0"

    val eventbusCore = "org.greenrobot:eventbus:${Versions.eventbus}"
    val eventbusNote = "org.greenrobot:eventbus-annotation-processor:${Versions.eventbus}"
    val glideCore = "com.github.bumptech.glide:glide:${Versions.glide}"
    val glideTrans = "jp.wasabeef:glide-transformations:${Versions.glideTrans}"
    val glideCompile="com.github.bumptech.glide:compiler:${Versions.glide}"
    val glideAnnotation = "androidx.annotation:annotation:1.0.0" //androidx注解迁移
    val buglyUpdate = "com.tencent.bugly:crashreport_upgrade:${Versions.crashUpdate}"

    //https://github.com/LuckSiege/PictureSelector
    val pictureSelector = "io.github.lucksiege:pictureselector:v2.7.3-rc08"

    //图片库摄像头，没有会报错
    val cameraCore = "androidx.camera:camera-core:1.0.0-rc05"
    val cameraLife = "androidx.camera:camera-lifecycle:1.1.0-alpha08"
    val cameraView = "androidx.camera:camera-view:1.0.0-alpha28"
    val arouterCore =
        "com.alibaba:arouter-api:${Versions.arouter}" //https://github.com/alibaba/ARouter
    val arouterNote = "com.alibaba:arouter-compiler:${Versions.arouterNote}"
    val easyPermission = "pub.devrel:easypermissions:3.0.0"
}

