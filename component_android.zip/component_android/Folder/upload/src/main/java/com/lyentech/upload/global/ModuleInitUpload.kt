package com.lyentech.upload.global

import com.alibaba.android.arouter.launcher.ARouter
import com.lyentech.common.global.ApplicationProvider
import com.lyentech.common.global.BaseModuleInit

class ModuleInitUpload : BaseModuleInit() {
    override fun onCreate() {
        super.onCreate()
        ARouter.openDebug()
        ARouter.openLog()
        ARouter.init(ApplicationProvider.appContext)
    }

    override val priority: Int
        get() = 1
}