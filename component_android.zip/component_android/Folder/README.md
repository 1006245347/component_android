------------
|作者|何伟杰|
|---|---
|邮箱| 260439@gree.com.cn
|备注|安卓 小程序 

## 分支管理
- master	线上发布环境代码版本，不要随意合并该处代码
- dev	业务功能迭代开发，请不要push bug的代码
- feature_vr	部分功能调试，如vr业务

## kotlin+mmvm+协程+组件化

|ip环境|自动打包渠道|ip地址|
|---|---|---
|生成环境|greePadpro|https://venus.leayun.cn/ |
|测试环境|greePaddev|http://134.175.221.224:23110/ |
|质控部测试|greePadque|http://106.55.33.186:23111/ |


## 路由组件v1.0[](http://119.23.107.222/department4/android-folder/tree/master/corelib/route)
架构说明：coreLib下的功能库，与app壳组件同级的是业务组件main、upload,创建新的组件必须修改跟build.gradle和
settings.gradle，当遇到无法依赖成功gradle构建失败，退出ide到文件夹下删除每个module的/build,
*.iml，.gradle,.idea文件（包括versions库）,所有的依赖库都由插件/app/versions.zip设置，将其解压放到与项目同级文件夹