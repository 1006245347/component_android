package com.lyentech.common.base

import androidx.core.content.FileProvider
/**
 * @author by jason-何伟杰，2022/3/8
 * des:重写fileProvider可以解决多库冲突
 */
class BaseFileProvider : FileProvider() {}