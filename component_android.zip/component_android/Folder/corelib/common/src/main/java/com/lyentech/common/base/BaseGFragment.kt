package com.lyentech.common.base

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.viewModelScope
import com.lyentech.common.global.GlobalCode
import com.lyentech.common.http.LoadState
import com.lyentech.common.widget.loading.GLoading
import com.lyentech.common.widget.loading.LoadProgressAdapter
import com.zh.xmindeasy.utils.ActivityStackUtil
import kotlinx.coroutines.cancel

/**
 * @author jason-何伟杰，2020-01-11
 * des:FragmentStatePagerAdapter会完全销毁滑动过去的item
 * FragmentPagerAdapter适合少量静态页面
 */
abstract class BaseGFragment : Fragment() {
    protected val mViewModel = createViewModel(GlobalVm())
    protected var mRootView: View? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mRootView = inflater.inflate(getLayoutId(), container, false)
        return mRootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView(savedInstanceState)
    }

    open fun initView(savedInstanceState: Bundle?) {

    }

    fun createViewModel(t: BaseGVm): BaseGVm {
        t.loadState.observe(viewLifecycleOwner, {
            when (it) {
                is LoadState.LoadSuc -> showLoadSuc()
                is LoadState.LoadFail -> showLoadErr(it.msg)
                is LoadState.Loading -> showLoading()
            }
        })
        return t
    }

    abstract fun getLayoutId(): Int

    protected fun getMyContext(): Context {
        return requireActivity()
    }

    override fun onDestroy() {
        super.onDestroy()
        mViewModel.viewModelScope.cancel()
    }

    protected var mLoading: GLoading.Holder? = null
    open fun initLoadingStatusViewIfNeed() {
        if (null == mLoading) {
            GLoading.initDefault(LoadProgressAdapter())  //写在app
            val loading = GLoading.getDefault()
            mLoading = loading.wrap(ActivityStackUtil.getCurAty()).withRetry { onLoadRetry() }
                .withCancel { onLoadCancel() }
        }
    }

    /**重新加载*/
    open fun onLoadRetry() {}

    open fun onLoadCancel(isCancel: Boolean = false) {
        if (isCancel)
            mViewModel.viewModelScope.cancel()
        initLoadingStatusViewIfNeed()
        mLoading?.showLoadSuccess()   //去除界面
    }

    /**显示加载中*/
    open fun showLoading() {
        initLoadingStatusViewIfNeed()
        mLoading?.showLoading()
        GlobalCode.printLog("load_ing")
    }

    /**显示加载成功*/
    open fun showLoadSuc() {
        initLoadingStatusViewIfNeed()
        mLoading?.showLoadSuccess()
        GlobalCode.printLog("load_suc")
    }

    /**显示加载失败*/
    open fun showLoadErr(str: String) {
        initLoadingStatusViewIfNeed()
        mLoading?.showLoadFailed()
    }

    /**显示加载的数据为空*/
    open fun showEmpty() {
        initLoadingStatusViewIfNeed()
        mLoading?.showEmpty()
    }
}