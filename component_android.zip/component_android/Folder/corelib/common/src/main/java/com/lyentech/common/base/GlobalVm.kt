package com.lyentech.common.base

/**
 * @author by jason-何伟杰，2022/3/10
 * des:通用viewModel
 */
class GlobalVm : BaseGVm() {
    //放通用业务函数
}