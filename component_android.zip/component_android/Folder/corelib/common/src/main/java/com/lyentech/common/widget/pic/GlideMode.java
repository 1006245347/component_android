package com.lyentech.common.widget.pic;

import android.content.Context;

import androidx.annotation.NonNull;

import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.load.engine.cache.DiskLruCacheFactory;
import com.bumptech.glide.module.AppGlideModule;
import com.lyentech.common.global.ApplicationProvider;

import java.io.File;

/**
 * @author by jason-何伟杰，2022/3/8
 * des:自定义glide缓存目录，大小
 */
@GlideModule
public class GlideMode extends AppGlideModule {

    @Override
    public void applyOptions(@NonNull Context context, @NonNull GlideBuilder builder) {
        int cacheSize = 600 * 1024 * 1024; //1000mb

        File file= ApplicationProvider.getImageCacheDir();
        builder.setDiskCache(new DiskLruCacheFactory(file.getAbsolutePath(), cacheSize));
    }

    @Override
    public boolean isManifestParsingEnabled() {
        return false;
    }
}
