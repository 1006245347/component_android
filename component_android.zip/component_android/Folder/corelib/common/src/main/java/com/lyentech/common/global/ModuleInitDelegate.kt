package com.lyentech.common.global

import android.content.Context

object ModuleInitDelegate : IModuleInit {

    private val moduleList = mutableListOf<IModuleInit>()

    fun register(vararg modules: IModuleInit) {
        moduleList.addAll(modules)
    }

    fun reorder() {
        moduleList.sortBy { (it as BaseModuleInit).priority }
    }

    override fun onCreate() {
        moduleList.forEach { it.onCreate() }
    }

    override fun attachBaseContext(base: Context) {
        moduleList.forEach { it.attachBaseContext(base) }
    }

    override fun onLowMemory() {
        moduleList.forEach { it.onLowMemory() }
    }

    override fun onTrimMemory(level: Int) {
        moduleList.forEach { it.onTrimMemory(level) }
    }

    override fun onTerminate() {
        moduleList.forEach { it.onTerminate() }
    }
}

interface IModuleInit{
    fun onCreate() {}
    fun attachBaseContext(base: Context) {}
    fun onLowMemory() {}
    fun onTrimMemory(level: Int) {}
    fun onTerminate() {}
}

abstract class BaseModuleInit: IModuleInit {
    /**
     * 模块初始化优先级 越高初始化越快
     * Module中设置优先级越小越优先初始化
     */
    open val priority: Int = 0
}