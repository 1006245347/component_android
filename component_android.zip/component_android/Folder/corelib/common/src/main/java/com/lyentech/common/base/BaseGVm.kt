package com.lyentech.common.base

import android.app.Application
import androidx.lifecycle.*
import com.lyentech.common.R
import com.lyentech.common.global.ApplicationProvider
import com.lyentech.common.global.GlobalCode
import com.lyentech.common.http.LoadState
import com.lyentech.common.utils.NetUtil
import com.lyentech.common.utils.ToastUtil
import com.lyentech.common.utils.UIhelper
import kotlinx.coroutines.*

/**
 * @author by jason-何伟杰，2020/4/21
 * des:MutableLiveData更新值在UI线程setValue(),在子线程postValue()
 */
abstract class BaseGVm(application: Application = ApplicationProvider.appContext) :
    AndroidViewModel(application) {
    /**LiveData可以在某个字段更新发出通知，MutableLiveData是整个类型变量*/
    /**loadState控制界面加载状态切换，加载中，加载成功，加载失败*/
    val loadState = MutableLiveData<LoadState>()
    var curJob: Job? = null

    //这里默认开启的是主线程。但是却能访问网络。。。
    fun launch(block: suspend CoroutineScope.() -> Unit): Job {
        curJob = viewModelScope.launch(Dispatchers.Main) {
            GlobalCode.printLog("launch-${Thread.currentThread().name}")
            try {
                loadState.value = LoadState.Loading()
                block()
                loadState.value = LoadState.LoadSuc()
            } catch (e: Exception) {
                handleErrLoad(e.message + "", false)
            }
            judgeAct()
        }
        return curJob as Job
    }

    open fun <T> execute(block: suspend LiveDataScope<T>.() -> T): LiveData<T> = liveData {
        curJob = viewModelScope.launch(Dispatchers.Main) {
            try {
                loadState.value = LoadState.Loading()
                emit(block())
                loadState.value = LoadState.LoadSuc()
            } catch (e: Exception) {
                handleErrLoad(e.message + "", false)
            }
            judgeAct()
        }
    }

    //这里是在子线程的
    fun launchSub(block: suspend CoroutineScope.() -> Unit): Job {
        curJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                loadState.postValue(LoadState.Loading())
                block()
                loadState.postValue(LoadState.LoadSuc())
            } catch (e: Exception) {    //注意，当数据解析错误也会进入showFailed()
                GlobalCode.printLog("launch_err:${e.message}")
                if (GlobalCode.showErr(e.message)) {
                    loadState.postValue(LoadState.LoadFail("${e.message}"))
                }
            }
            judgeAct()
        }
        return curJob as Job
    }

    //这里是在子线程的
    fun <T> executeSub(block: suspend LiveDataScope<T>.() -> T): LiveData<T> = liveData {
        curJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                loadState.postValue(LoadState.Loading())
                emit(block())
                loadState.postValue(LoadState.LoadSuc())
            } catch (e: Exception) {
                handleErrLoad(e.message + "")
            }
            judgeAct()
        }
    }

    //请求列表数据的封装，拿到数据loadRefresh()
    fun launchList(block: suspend CoroutineScope.() -> Unit): Job {
        return viewModelScope.launch(Dispatchers.IO) {
            try {
                loadState.postValue(LoadState.Loading())
                block()
                loadState.postValue(LoadState.LoadRefresh())
            } catch (e: Exception) {
                e.printStackTrace()
                loadState.postValue(LoadState.LoadRefresh("error-"))
            }
            judgeAct()
        }
    }

    //没有任务交互提示地执行
    fun launchQuiet(block: suspend CoroutineScope.() -> Unit): Job {
        return viewModelScope.launch(Dispatchers.IO) {
            try {
                block()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    //延迟执行
    fun delayMain(runnable: Runnable?, mills: Long = 2000) {
        viewModelScope.launch(Dispatchers.Main) {
            delay(mills)
            runnable?.run()
        }
    }

    //显示加载图并延时执行
    fun showLoadingView(mills: Long = 1000, runnable: Runnable?) {
        viewModelScope.launch(Dispatchers.Main) {
            loadState.postValue(LoadState.Loading())
            delay(mills)
            loadState.postValue(LoadState.LoadSuc())
            runnable?.run()
        }
    }

    //判断网络状态
    private fun judgeAct() {
        if (!NetUtil.isConnected(UIhelper.getContext())) {
            ToastUtil.showToast(
                UIhelper.getContext(),
                UIhelper.getString(R.string.load_failed_no_network)
            )
        }
    }

    //统一处理所有异常信息
    private fun handleErrLoad(str: String, isIO: Boolean = true) {
        GlobalCode.printLog("http_err:$str")
        if (GlobalCode.showErr(str)) {
            if (isIO) {
                loadState.postValue(LoadState.LoadFail(str))
            } else {
                loadState.value = LoadState.LoadFail(str)
            }
        } else {
            if (isIO) {
                loadState.postValue(LoadState.LoadSuc())
            } else {
                loadState.value = LoadState.LoadSuc()
            }
        }
    }

    //取消所有的线程协程任务
    fun cancel() {
        this.viewModelScope.cancel()
    }
}