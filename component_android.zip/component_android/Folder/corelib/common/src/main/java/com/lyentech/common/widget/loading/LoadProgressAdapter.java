package com.lyentech.common.widget.loading;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.lyentech.common.R;
import com.lyentech.common.utils.NetUtil;

import static com.lyentech.common.widget.loading.GLoading.STATUS_EMPTY_DATA;
import static com.lyentech.common.widget.loading.GLoading.STATUS_LOADING;
import static com.lyentech.common.widget.loading.GLoading.STATUS_LOAD_FAILED;
import static com.lyentech.common.widget.loading.GLoading.STATUS_LOAD_SUCCESS;

public class LoadProgressAdapter implements GLoading.Adapter {

    @Override
    public View getView(GLoading.Holder holder, View convertView, int status) {
        ProgressView progressView = null;
        if (convertView instanceof ProgressView) {
            progressView = (ProgressView) convertView;
        }
        if (null == progressView) {
            progressView = new ProgressView(holder.getContext(), holder.getRetryTask(), holder.getCancelTask());
        }
        progressView.setStatus(status);
        return progressView;
    }

    static class ProgressView extends RelativeLayout implements View.OnClickListener {
        private TextView tvLoading;
        private ImageView ivCancel;
        private Runnable mRetryTask, mCancelTask;

        public ProgressView(Context context, Runnable retryTask, Runnable cancelTask) {
            super(context);
            LayoutInflater.from(context).inflate(R.layout.layout_loading, this);
            tvLoading = findViewById(R.id.tv_loading);
            ivCancel = findViewById(R.id.iv_cancel);
            this.mRetryTask = retryTask;
            this.mCancelTask = cancelTask;
        }

        public void setStatus(int status) {
            boolean show = true;
            int str = R.string.warning_empty;
            switch (status) {
                case STATUS_LOAD_SUCCESS:
                    show = false;
                    break;
                case STATUS_LOADING:
                    str = R.string.loading;
                    break;
                case STATUS_LOAD_FAILED:
                    str = R.string.load_err;
                    boolean networkConn = NetUtil.isConnected(getContext());
                    if (!networkConn) {
                        str = R.string.load_failed_no_network;
                    }
                    break;
                case STATUS_EMPTY_DATA:
                    str = R.string.warning_empty;
                    break;
            }
            findViewById(R.id.rl_loading).setOnClickListener(this);
            tvLoading.setOnClickListener(this);
            ivCancel.setOnClickListener(this);
            tvLoading.setText(str);
            setVisibility(show ? View.VISIBLE : View.GONE);
        }

        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.iv_cancel) {
                if (mCancelTask != null)
                    mCancelTask.run();
            } else if (v.getId() == R.id.tv_loading) {
                if (mRetryTask != null)
                    mRetryTask.run();
            } else if (v.getId() == R.id.rl_loading) {
                if (mRetryTask != null)
                    mRetryTask.run();
            } else if (v.getId() == R.id.rl_root3) {
            }
        }
    }
}
