package com.lyentech.common.listener;

public interface ItemClickCallback {

    void onItemClick(int position, String des, String tag);
}
