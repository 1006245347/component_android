package com.lyentech.common.listener;

public interface ResultCallback {

    void dialogCallback(String result);
}
