package com.lyentech.common.utils

import android.app.Activity
import android.view.View

/**
 * @author jason-何伟杰，2020-01-05
 * des:
 */
object ViewUtil {
    /**
     * activity.findViewById()
     *
     * @param context
     * @param id
     * @return
     */
    fun <T : View> f(context: Activity, id: Int): T {
        return context.findViewById<View>(id) as T
    }

    /**
     * rootView.findViewById()
     *
     * @param rootView
     * @param id
     * @return
     */
    fun <T : View> f(rootView: View, id: Int): T {
        return rootView.findViewById<View>(id) as T
    }
}

/**单例模式*/
class Singlenton private constructor() {
    var value: Singlenton? = null

    private object mHolder {
        val INSTASCE = Singlenton()
    }

    companion object Factory {
        @JvmStatic
        fun getInstance(): Singlenton {
            return mHolder.INSTASCE
        }
    }
}