package com.zh.xmindeasy.utils

import android.app.Activity
import java.util.*

/**
 * @author jason-何伟杰，2020-01-05
 * des:应用中所有Activity的管理器，可用于一键杀死所有Activity。
 */
object ActivityStackUtil {
    private val activityStack = Stack<Activity>()

    @JvmStatic
    fun add(weakRefActivity: Activity?) {
        weakRefActivity?.let { activityStack.add(it) }
    }

    @JvmStatic
    fun del(weakRefActivity: Activity?) {
        weakRefActivity?.let {
            it.finish()
            activityStack.remove(it)
        }
    }

    @JvmStatic
    fun getCurAty(): Activity {
        return activityStack[activityStack.size - 1]
    }

    //关闭其他Activity
    @JvmStatic
    fun <T> finishOther(cls: Class<T>) {
        for (aty in activityStack) {
            if (aty::class.java != cls) {
                del(aty)
                break
            }
        }
    }

    @JvmStatic
    fun <T> findAty(cls: Class<T>): Activity? {
        for (aty in activityStack) {
            if (aty::class.java == cls) {
                return aty
            }
        }
        return null
    }

    @JvmStatic
    fun clearAll() {
        if (activityStack.isNotEmpty()) {
            for (activity in activityStack) {
                activity?.finish()
            }
            activityStack.clear()
        }
    }
}