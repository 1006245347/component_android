package com.lyentech.common.http
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.http.*

/**
 * @author jason-何伟杰，2020-01-07
 * des:retrofit+协程
 */
interface ApiService {

    @GET
    suspend fun doGetRequest(@Url url: String): ResponseBody

    @FormUrlEncoded
    @POST
    suspend fun doJsonRequest(@Url url: String, @Body requestBody: RequestBody): ResponseBody

    @FormUrlEncoded
    @POST
    suspend fun doHttpRequest(@Url url: String, @FieldMap map: Map<String, String>): ResponseBody

//    @GET("image/sogou/api.php") //https://api.ooopn.com/image/sogou/api.php?type=json
//    suspend fun doGetImage(@Query("type")type:String="json"):ResponseBody

    @Multipart
    @POST
    suspend fun upload2File(
        @Url url: String,
        @Part file: MultipartBody.Part,
        @PartMap params: HashMap<String, RequestBody>
    ): ResponseBody
}

interface ProgressListener {
    fun onProgress(progress: Long, total: Long)
}

//suspend fun RetrofitFactory.doHttpGet(
//    url: String
//): String {
//    return RetrofitFactory.doGetRequest(url)
//}
