package com.lyentech.common.http

import android.app.LauncherActivity
import android.text.TextUtils
import com.google.gson.Gson
import com.google.gson.JsonParser
import com.lyentech.common.global.BaseConfig
import com.lyentech.common.global.BaseUrl
import com.lyentech.common.global.GlobalCode
import com.lyentech.common.global.HttpListResponse
import com.lyentech.common.utils.MMKVUtil
import com.lyentech.common.utils.ToastUtil
import com.zh.xmindeasy.utils.ActivityStackUtil
import okhttp3.*
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * @author jason-何伟杰，2020-01-07
 * des:
 */
class RetrofitFactory private constructor() {
    private val retrofit: Retrofit

    init {
        val gson = Gson().newBuilder()
            .setLenient()
            .serializeNulls()
            .create()
        retrofit = Retrofit.Builder()
            .baseUrl(BaseUrl.BASE_IP)
            .client(initOkHttpClient())
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
    }

    companion object {
        private val instance: RetrofitFactory by lazy(mode = LazyThreadSafetyMode.SYNCHRONIZED) {
            RetrofitFactory()
        }

        private fun parseResponse(result: String): String {
            return if (!GlobalCode.IS_ENCRY) { //暂时没有加密
                stateResponse(result)
            } else {
                stateResponse(result)
            }
        }

        private fun stateResponse(result: String): String {
            GlobalCode.printLog("http_result:$result")
            var jo: JSONObject? = null
            try {
                jo = JSONObject(result) //如果接口崩了，会乱码造成崩溃
            } catch (e: Exception) {
                e.printStackTrace()
                return ""
            }
            return when {
                "0" == jo.optString("code") -> result
                "0" == jo.optString("State") -> result
                "401" == jo.optString("code") -> {
                    if (ActivityStackUtil.getCurAty() == ActivityStackUtil.findAty(LauncherActivity::class.java)) {
                        return ""
                    }
                    ToastUtil.showToast("登录失效,请重新登录!")
                    MMKVUtil.remove(BaseConfig.DATA_APP_TOKEN)
                    GlobalCode.TOKEN = ""
                    ""
                }
                BaseConfig.CODE_HTTP_ID_PERMISSION.toString() == jo.optString("code") -> {
                    "{ \"message\":\"无权限\",\"code\":${BaseConfig.CODE_HTTP_ID_PERMISSION} }"
                }
                else -> { //如果code不等于0，那么将整个返回体置null
                    ToastUtil.showToast("${jo.optString("message")}")
                    return ""  //注意这里-所有异常都会返回一个空字符
                }
            }
        }

        fun <T> getResponse(result: String, cls: Class<T>): T? {
            if (TextUtils.isEmpty(result)) {
                return null
            } else {
                val jo = JSONObject(result)
//                GlobalCode.printLog("${Thread.currentThread().name}-getResponse: $result")
                var t: T?
                val gson = Gson()
                t = gson.fromJson(jo.getJSONObject("data").toString(), cls)
                GlobalCode.printLog("t==" + t)
                return t
            }
        }

        fun <T> getListResponse(result: String, cls: Class<T>): HttpListResponse<T> {
            GlobalCode.printLog("listResponse:${Thread.currentThread().name}")
            val list = mutableListOf<T>()
            var ok = result
            if (TextUtils.isEmpty(result)) {
                ok =
                    "{ \"message\":\"服务异常\",\"code\":777 ,\"data\":{\"select\":[],\"pagination\":{}}}"
            }
            val jo = JSONObject(ok)
            val jdata = jo.optJSONObject("data")
            val jarr = jdata?.optJSONArray("select")
            val gson = Gson()
            val array = JsonParser().parse(jarr.toString() + "").asJsonArray
            for (ele in array) {
                list.add(gson.fromJson(ele, cls))
            }
            val jpage = jdata?.getJSONObject("pagination")
            var pageCount = 1
            var totalCount = 0
            jpage?.let {
                pageCount = jpage.optInt("pageCount")
                totalCount = jpage.optInt("totalCount")
            }
            val httpListResponse = HttpListResponse<T>()
            val listPage = HttpListResponse.PageCount()
            listPage.pageCount = pageCount
            listPage.totalCount = totalCount
            httpListResponse.pagination = listPage
            httpListResponse.select = list
            return httpListResponse
        }

        private fun getLocalToken(): String {
            if (GlobalCode.TOKEN.isNullOrBlank()) {
                return ""
            }
            return "?token=${GlobalCode.TOKEN}" //不同后台不一样key
        }

        suspend fun doGetRequest(url: String, otherArg: String = ""): String {
            GlobalCode.printLog("doGet-${Thread.currentThread().name}>>$url")
            var result: String
            result = try {
                instance.createService(ApiService::class.java)
                    .doGetRequest(url + getLocalToken() + otherArg).string()
            } catch (e: Exception) {
                e.printStackTrace()
                "{ \"message\":\"服务异常\",\"code\":777 }"
            }
            return parseResponse(result)
        }

        suspend fun doPostRequest(
            url: String,
            map: MutableMap<String, String>,
            otherArg: String = ""      //"&page_size=${CommunityConfig.LOAD_SIZE_IN_PAGE}&page=$curPage"
        ): String {
            GlobalCode.printLog("url:" + url + getLocalToken() + otherArg)
            var result: String
            try {
                result = instance.createService(ApiService::class.java)
                    .doHttpRequest(url + getLocalToken() + otherArg, map).string()
            } catch (e: Exception) {
                e.printStackTrace()
                result = "{ \"message\":\"服务异常\",\"code\":777 }"
            }
            return parseResponse(result)
        }

        suspend fun doPostJsonRequest(
            url: String,
            jsonParam: String,
            otherArg: String = ""
        ): String {
            var result: String
            result = try {
                val type = MediaType.parse("application/json;charset=utf-8")
                val body = RequestBody.create(type, jsonParam)
                instance.createService(ApiService::class.java)
                    .doJsonRequest(url + getLocalToken() + otherArg, body).string()
            } catch (e: Exception) {
                e.printStackTrace()
                "{ \"message\":\"服务异常\",\"code\":777 }"
            }
            return parseResponse(result)
        }

        suspend fun <T> doGetResponse(url: String, cls: Class<T>): T? {
            return getResponse(doGetRequest(url), cls)
        }

        suspend fun <T> doPostResponse(
            url: String,
            map: MutableMap<String, String>,
            cls: Class<T>
        ): T? {
            return getResponse(doPostRequest(url, map), cls)
        }

        suspend fun <T> dostPostJsonResponse(url: String, jsonParam: String, cls: Class<T>): T? {
            return getResponse(doPostJsonRequest(url, jsonParam), cls)
        }

        suspend fun upload2File(
            url: String,
            paramsMap: HashMap<String, RequestBody>,
            fileKey: String,
            filePath: String,
            progressListener: ProgressListener
        ): ResponseBody {
            val requestBody = RequestBody.create(MediaType.parse("image/*"), File(filePath))
            val fileRequestBody =
                UploadFileRequestBody(requestBody, progressListener)
            val part =
                MultipartBody.Part.createFormData(fileKey, File(filePath).name, fileRequestBody)
            return instance.createService(ApiService::class.java).upload2File(url, part, paramsMap)
        }
    }

    private fun initOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()
    }

    fun <T> createService(api: Class<T>): T {
        return retrofit.create(api)
    }
}