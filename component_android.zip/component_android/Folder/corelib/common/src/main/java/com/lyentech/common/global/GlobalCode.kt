package com.lyentech.common.global

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.text.TextUtils
import android.text.format.DateUtils
import android.util.Log
import com.bumptech.glide.Glide
import com.lyentech.common.utils.MD5Util
import okhttp3.MediaType
import okhttp3.RequestBody
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * @author jason-何伟杰，2020-01-05
 * des:全局调用
 */
object GlobalCode {

    @JvmField
    var IS_DEBUG = true

    @JvmField
    var IS_ENCRY = false

    @JvmField
    var HOST_IP = if (IS_DEBUG) "ip1" else "ip2"

    private const val APP_TAG = "TAG"

    @JvmField
    var TOKEN: String? = null

    @JvmField
    var curLng: Double = 0.0

    @JvmField
    var curLat: Double = 0.0

    @JvmStatic
    fun printLog(msg: String) {
//        if (!IS_DEBUG) return
        if (msg.isEmpty()) return
        var log = msg
        val segmentSize = 3 * 1024
        val length = log.length
        if (length <= segmentSize) {
//            Log.e(APP_TAG, "${Thread.currentThread().stackTrace[0].lineNumber}::$log")
            Log.e(
                APP_TAG,
                "Method:{${Throwable().stackTrace[1].methodName}}-${Throwable().stackTrace[1].lineNumber}::$log"
            )
        } else {
            while (log.length > segmentSize) {
                val logContent = log.substring(0, segmentSize)
                log = log.replace(logContent, "")
                Log.e(APP_TAG, "\n$logContent")
            }
            Log.e(APP_TAG, "\n$log")
        }
    }

    @JvmStatic
    fun printLog(throwable: Throwable) {
        Log.e(APP_TAG, Log.getStackTraceString(throwable))
    }

    @JvmStatic //出现协程的完成、取消异常不弹提示
    fun showErr(err: String?):Boolean {
        err?.let {
            if (err.contains("was cancelled") || err.contains("has completed normally")) {
                return false
            }
        }
        return true
    }

    /** @return 公共加密参数*/
    @JvmStatic
    fun encryArgs(map: MutableMap<String, String>?): MutableMap<String, String> {
        if (map.isNullOrEmpty()) {
            val map = mutableMapOf<String, String>()
            val time = System.currentTimeMillis()
            val strMd5 = MD5Util.encrypBy(time.toString() + "zlsjapp" + "zl-yii2")
            if (!TextUtils.isEmpty(TOKEN))
                map["token"] = TOKEN + ""
            map["timeStamp"] = "$time"
            map["certificationName"] = "zlsjapp"
            map["sign"] = strMd5
            return map
        } else {
            val time = System.currentTimeMillis()
            val strMd5 = MD5Util.encrypBy(time.toString() + "zlsjapp" + "zl-yii2")
            if (!TextUtils.isEmpty(TOKEN))
                map["token"] = TOKEN + ""
            map["timeStamp"] = "$time"
            map["certificationName"] = "zlsjapp"
            map["sign"] = strMd5
            printLog("Post_args:$map")
            return map
        }
    }

    /** @return 参数包装*/
    @JvmStatic
    fun toRequestBody(value: String): RequestBody {
        return RequestBody.create(MediaType.parse("text/plain"), value)
    }

    @JvmStatic
    fun makeCall(context: Context, phone: String = "13232508893") {
        val uri = Uri.parse("tel:$phone")
        context.startActivity(Intent(Intent.ACTION_DIAL, uri))
    }

    @JvmStatic
    fun makeSms(context: Context, phone: String = "13232508893") {
        val uri = Uri.parse("smsto:$phone")
        val intent = Intent(Intent.ACTION_SENDTO, uri)
        intent.putExtra("sms_body", "来自我社区：")
        context.startActivity(intent)
    }

    /**
     * @return 米 补充：计算两点之间真实距离
     */
    @JvmStatic
    fun getDistance(
        longitude1: Double,
        latitude1: Double,
        longitude2: Double = curLng,
        latitude2: Double = curLat
    ): Double {
        try {
            printLog("cur_lng=$longitude2")
            // 维度
            val lat1 = Math.PI / 180 * latitude1
            val lat2 = Math.PI / 180 * latitude2

            // 经度
            val lon1 = Math.PI / 180 * longitude1
            val lon2 = Math.PI / 180 * longitude2

            // 地球半径
            val R = 6371.0

            // 两点间距离 km，如果想要米的话，结果*1000就可以了
            val d = Math.acos(
                Math.sin(lat1) * Math.sin(lat2) + Math.cos(lat1) * Math.cos(
                    lat2
                ) * Math.cos(lon2 - lon1)
            ) * R
            return d * 1000
        } catch (e: Exception) {
            e.printStackTrace()
            return 9999000.0
        }
    }

    /**转为字符串文本*/
    @JvmStatic
    fun formatTime(time: String): String =
        formatTimeStamp(time).let {
            DateUtils.getRelativeTimeSpanString(it).toString()
        }

    /**转为时间戳*/
    @JvmStatic
    fun formatTimeStamp(time: String): Long =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA)
            .let {
                it.timeZone = TimeZone.getTimeZone("GMT+8")
                it.parse(time).time
            }

    @JvmStatic
    fun Date2Str(date: Date = Date(), pattern: String = "yyyy MM dd HH:mm:ss"): String {
        val format = SimpleDateFormat(pattern)
        return format.format(date)
    }

    @JvmStatic
    fun long2DateStr(date: Long, pattern: String = "yyyyHHdd"): String {
        return SimpleDateFormat(pattern).format(date)
    }

    @JvmStatic
    fun compressBitmap(pathName: String): String {
        val newPath = createImagePath()
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true // 只获取图片的大小信息，而不是将整张图片载入在内存中，避免内存溢出
        BitmapFactory.decodeFile(pathName, options)
        val height = options.outHeight
        val width = options.outWidth
        var inSampleSize = 2  // 默认像素压缩比例，压缩为原图的1/2
        val minLen = Math.min(height, width)  // 原图的最小边长
        if (minLen > 100) { // 如果原始图像的最小边长大于100dp（此处单位我认为是dp，而非px）
            val ratio = minLen / 330.0f // 计算像素压缩比例  3M->120kb
            inSampleSize = ratio.toInt()
        }
        options.inJustDecodeBounds = false  // 计算好压缩比例后，这次可以去加载原图了
        options.inSampleSize = inSampleSize // 设置为刚才计算的压缩比例
        val bm = BitmapFactory.decodeFile(pathName, options) // 解码文件
        var fos = FileOutputStream(newPath)
        try {
            bm.compress(Bitmap.CompressFormat.JPEG, 100, fos)
            fos.flush()
            fos.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return newPath
    }

    @JvmStatic
    fun createImagePath(): String {
        return ApplicationProvider.getImageCacheDir()?.absolutePath + "/" + System.currentTimeMillis() + ".jpg"
    }

    /**最好开个协程*/
    @JvmStatic
    fun clearCache(mContext: Context) {
        /*清除内存*/
        Glide.get(mContext).clearMemory()
        /*清除磁盘*/
        Glide.get(mContext).clearDiskCache()
    }

    @JvmStatic
    fun getRandColor(): String? {
        var R: String
        var G: String
        var B: String
        val random = Random()
        R = Integer.toHexString(random.nextInt(256)).toUpperCase()
        G = Integer.toHexString(random.nextInt(256)).toUpperCase()
        B = Integer.toHexString(random.nextInt(256)).toUpperCase()
        R = if (R.length == 1) "0$R" else R
        G = if (G.length == 1) "0$G" else G
        B = if (B.length == 1) "0$B" else B
        return "#$R$G$B"
    }
}