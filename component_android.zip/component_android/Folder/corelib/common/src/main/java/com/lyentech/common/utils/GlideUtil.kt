package com.lyentech.common.utils

import android.content.Context
import android.graphics.drawable.Drawable
import android.widget.ImageView
import com.bumptech.glide.GenericTransitionOptions
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.lyentech.common.R
import jp.wasabeef.glide.transformations.RoundedCornersTransformation

/**
 * @author jason-何伟杰，2020-01-06
 * des:图片管理
 */
object GlideUtil {

    fun loadImg(context: Context, path: String?, iv: ImageView) {
        Glide.with(context).load(path + "").diskCacheStrategy(DiskCacheStrategy.RESOURCE)
            .placeholder(R.drawable.ic_base_def).centerCrop().into(iv)
    }

    /**圆形图片*/
    fun loadCirView(context: Context, path: String?, iv: ImageView) {
        Glide.with(context).load(path + "").diskCacheStrategy(DiskCacheStrategy.RESOURCE)
            .placeholder(R.drawable.ic_base_def)
            .apply(
                RequestOptions.bitmapTransform(
                    RoundedCornersTransformation(
                        20, 0, RoundedCornersTransformation.CornerType.ALL
                    )
                )
            )
            .into(iv)
    }

    /**替换默认图片*/
    fun loadImgDef(context: Context, path: String?, iv: ImageView, def: Int) {
        Glide.with(context).load(path + "").diskCacheStrategy(DiskCacheStrategy.RESOURCE)
            .placeholder(def).error(def)
            .into(iv)
    }

    /**替换默认,错误图片*/
    fun loadImgDef(context: Context, path: String?, iv: ImageView, def: Int, err: Int) {
        Glide.with(context).load(path + "").diskCacheStrategy(DiskCacheStrategy.RESOURCE)
            .placeholder(def).error(err)
            .into(iv)
    }

    /**图片大小*/
    fun loadRealSizeImg(
        context: Context,
        path: String?,
        width: Int,
        height: Int,
        iv: ImageView,
        loding: Int,
        err: Int
    ) {
        Glide.with(context).load(path + "").diskCacheStrategy(DiskCacheStrategy.RESOURCE)
            .override(width, height)
            .placeholder(loding).error(err)
            .into(iv)
    }

    /**加载动画*/
    fun loadAnimImg(context: Context, path: String, anim: Int, iv: ImageView) {
        Glide.with(context).load(path).transition(GenericTransitionOptions.with(anim))
            .into(iv)
    }

    fun loadGif(context: Context, path: String, iv: ImageView) {
        Glide.with(context).asGif().load(path).into(iv)
    }

    fun clearCache(context: Context) {
        Glide.get(context).clearDiskCache()
    }

    /**加载图片时做监听*/
    fun loadCallback(
        context: Context,
        path: String?,
        iv: ImageView,
        okCall: Runnable?,
        errCall: Runnable?
    ) {
        Glide.with(context).load(path + "")
            .listener(object : RequestListener<Drawable> {
                /** return false 未消费，继续走into(imageview)*/
                /** return true  已消费，不再走into(imageview)*/
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>?,
                    isFirstResource: Boolean
                ): Boolean {
                    errCall?.run()
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable?,
                    model: Any?,
                    target: Target<Drawable>?,
                    dataSource: DataSource?,
                    isFirstResource: Boolean
                ): Boolean {
                    okCall?.run()
                    return false
                }
            }).into(iv)

    }
}