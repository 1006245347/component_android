package com.lyentech.common.http

/**
 * @author jason-何伟杰，2020-01-10
 * des:网络状态切换
 */
sealed class LoadState(val msg: String) {
    class Loading(msg: String = "") : LoadState(msg)
    class LoadSuc(msg: String = "") : LoadState(msg)
    class LoadFail(msg: String) : LoadState(msg)
    class LoadRefresh(msg: String = "") : LoadState(msg)
}