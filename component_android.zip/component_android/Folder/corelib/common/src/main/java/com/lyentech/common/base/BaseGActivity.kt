package com.lyentech.common.base

import android.app.Activity
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.google.android.material.appbar.MaterialToolbar
import com.gyf.immersionbar.ImmersionBar
import com.lyentech.common.R
import com.lyentech.common.global.BaseConfig
import com.lyentech.common.global.GlobalCode
import com.lyentech.common.http.LoadState
import com.lyentech.common.utils.UIhelper
import com.lyentech.common.widget.loading.GLoading
import com.lyentech.common.widget.loading.LoadProgressAdapter
import com.scwang.smart.refresh.footer.ClassicsFooter
import com.scwang.smart.refresh.header.ClassicsHeader
import com.scwang.smart.refresh.layout.SmartRefreshLayout
import com.zh.xmindeasy.utils.ActivityStackUtil
import kotlinx.coroutines.cancel

/**
 * @author by jason-何伟杰，2022/3/10
 * des:mmvm封装基类
 */
abstract class BaseGActivity : AppCompatActivity() {
    private var weakRefActivity: Activity? = null
    protected var titleBar: MaterialToolbar? = null
    protected var refreshRoot: SmartRefreshLayout? = null
    protected var rvList: RecyclerView? = null
    protected var mCurPage = BaseConfig.LOAD_START_PAGE
    protected var mAdapter: BaseQuickAdapter<*, *>? = null
    protected val mViewModel = createViewModel(GlobalVm()) as GlobalVm

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        weakRefActivity = this
        ActivityStackUtil.add(weakRefActivity)
        setContentView(getLayoutId())
        initImmersionBar()
        initAty()
    }

    open fun initImmersionBar() {
        titleBar = findViewById(R.id.baseToolbar)
        ImmersionBar.with(this)
            .statusBarColor(R.color.cGrey)
            .statusBarDarkFont(true) //顶部状态栏字体
            .titleBar(titleBar) //标题栏
            .navigationBarColor(R.color.cBlack).init() //底部导航栏
    }

    abstract fun initAty()
    abstract fun getLayoutId(): Int

    fun createViewModel(t: BaseGVm): BaseGVm {
        t.loadState.observe(this, {
            when (it) {
                is LoadState.LoadSuc -> showLoadSuc()
                is LoadState.LoadFail -> showLoadErr(it.msg)
                is LoadState.Loading -> showLoading()
                is LoadState.LoadRefresh -> loadComplete(it.msg)
            }
        })
        return t
    }

    fun getCurAty(): AppCompatActivity {
        return this
    }

    override fun onDestroy() {
        super.onDestroy()
        /**取消ViewModel运行的所有协程所用的任务*/
        mViewModel.viewModelScope.cancel()

        ActivityStackUtil.del(weakRefActivity)
    }

    private var mLoading: GLoading.Holder? = null
    open fun initLoadingStatusViewIfNeed() {
        try {
            if (null == mLoading) {
                GLoading.initDefault(LoadProgressAdapter())  //写在app
                val loading = GLoading.getDefault()
                mLoading =
                    loading.wrap(this).withRetry { onLoadRetry() }.withCancel { onLoadCancel() }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**重新加载*/
    open fun onLoadRetry() {

    }

    /**取消请求*/
    open fun onLoadCancel(isCancel: Boolean = false) {
        if (isCancel)
            mViewModel.viewModelScope.cancel()
        initLoadingStatusViewIfNeed()
        mLoading?.showLoadSuccess()
    }

    /**显示加载中*/
    open fun showLoading() {
        initLoadingStatusViewIfNeed()
        mLoading?.showLoading()
        GlobalCode.printLog("load_ing")
    }

    /**显示加载成功*/
    open fun showLoadSuc() {
        initLoadingStatusViewIfNeed()
        mLoading?.showLoadSuccess()
        GlobalCode.printLog("load_suc")
    }

    /**显示加载失败*/
    open fun showLoadErr(str: String) {
        initLoadingStatusViewIfNeed()
        if (GlobalCode.showErr(str)) {
            mLoading?.withData(str)
            mLoading?.showLoadFailed()
        }
        GlobalCode.printLog(str + " " + mLoading?.getData<String>())
    }

    /**显示加载的数据为空*/
    open fun showEmpty() {
        initLoadingStatusViewIfNeed()
        mLoading?.showEmpty()
    }

    open fun loadComplete(str: String? = null) {
        refreshRoot?.let {
            GlobalCode.printLog("loadComplete>>")
            it.finishRefresh()
            it.finishLoadMore()

            mAdapter?.let {
                if (mAdapter?.data?.size == 0) {
                    if (mCurPage == 0) {
                        mAdapter?.setList(arrayListOf())
                        addEmptyView()
                    }
                    if (mAdapter?.data!!.size > 0) { //加载更多没有数据
                        refreshRoot?.finishLoadMoreWithNoMoreData()
                    }
                } else {
                    //有数据返回没有处理
                }
            }
        }
    }

    open fun addEmptyView() {
        refreshRoot?.setEnableLoadMore(false)
        val emptyView = layoutInflater.inflate(R.layout.empty_view, rvList, false)
        emptyView.setOnClickListener { refreshRoot?.autoRefresh() }
        mAdapter?.setEmptyView(emptyView)
    }

    //列表数据封装初始化
    protected fun initCommonRv(runnable: Runnable? = null, num: Int = 1) {
        rvList = findViewById(R.id.rvList)
        rvList?.layoutManager = GridLayoutManager(getCurAty(), num)
        refreshRoot?.let {
            val header = ClassicsHeader(getCurAty())
            header.setPrimaryColor(UIhelper.getColor(R.color.cGrey))
            header.setAccentColor(UIhelper.getColor(R.color.cBlack))
            it.setRefreshHeader(header)
            it.setRefreshFooter(ClassicsFooter(getCurAty()))
            it.setEnableLoadMore(false)
            it.setEnableHeaderTranslationContent(true)
            it.setEnableFooterFollowWhenNoMoreData(true)
            it.setEnableScrollContentWhenRefreshed(true)
            it.setPrimaryColorsId(R.color.cWhite)
            it.setOnRefreshListener {
                refreshRoot?.resetNoMoreData()
                mCurPage = BaseConfig.LOAD_START_PAGE
                runnable?.run()
                refreshRoot?.setEnableLoadMore(false)
            }
            it.setOnLoadMoreListener {
                runnable?.run()
            }
        }
    }
}