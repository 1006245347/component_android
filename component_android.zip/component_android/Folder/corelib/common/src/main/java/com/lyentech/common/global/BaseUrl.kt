package com.lyentech.common.global

object BaseUrl {

    const val BASE_IP = "http://121.4.191.252:8082"

    //∆用户 -登录
    const val url_login = "$BASE_IP/user/login"
}