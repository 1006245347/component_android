package com.lyentech.common.utils

import android.content.Context
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.lyentech.common.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

/**
 * @author jason-何伟杰，2020-01-06
 * des:不能在子线程弹出
 */
object ToastUtil {

    private var mToast: Toast? = null

    @JvmStatic
    fun showToast(context: Context, txt: String) {
        if (TextUtils.isEmpty(txt)) return
        try {
            GlobalScope.launch(Dispatchers.Main) {
                if (null == mToast) {
                    if (Looper.myLooper() == null)
                        Looper.prepare();
                    mToast = Toast(context)
                    val layout = View.inflate(context, R.layout.layout_toast, null)
                    val tvDes = layout.findViewById(R.id.tv_des) as TextView
                    tvDes.text = txt
                    mToast!!.view = layout
                    mToast!!.setGravity(Gravity.FILL_HORIZONTAL, 0, 0)
                } else {
                    val textView = mToast!!.view?.findViewById(R.id.tv_des) as TextView
                    textView.text = txt
                }
                mToast!!.duration = Toast.LENGTH_SHORT
                mToast!!.show()
//                Looper.loop()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JvmStatic
    fun showToast(txt: String) {
        showToast(UIhelper.getContext(), txt)
    }
}