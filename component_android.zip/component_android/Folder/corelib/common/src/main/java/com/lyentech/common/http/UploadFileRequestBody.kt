package com.lyentech.common.http

import okhttp3.MediaType
import okhttp3.RequestBody
import okio.*
import java.io.IOException

class UploadFileRequestBody(private val requestBody: RequestBody, val progressListener: ProgressListener) :
    RequestBody() {

    private var mCountingSink: CountingSink? = null

    override fun contentType(): MediaType? {
        return requestBody.contentType()
    }

    override fun contentLength(): Long {
        try {
            return requestBody.contentLength()
        } catch (e: IOException) {
            e.printStackTrace()
            return -1
        }
    }

    override fun writeTo(sink: BufferedSink) {
        mCountingSink = CountingSink(sink)
        val bufferedSink: BufferedSink = Okio.buffer(mCountingSink)
        requestBody.writeTo(bufferedSink)
        bufferedSink.flush()
    }

    internal inner class CountingSink(delegate: Sink?) :
        ForwardingSink(delegate) {
        private var bytesWritten: Long = 0

        @Throws(IOException::class)
        override fun write(source: Buffer, byteCount: Long) {
            super.write(source, byteCount)
            bytesWritten += byteCount
//            progressListener.onProgress(bytesWritten, contentLength())
            var cur: Long = (bytesWritten * 100 / contentLength())
            progressListener.onProgress(cur, contentLength())
        }
    }
}