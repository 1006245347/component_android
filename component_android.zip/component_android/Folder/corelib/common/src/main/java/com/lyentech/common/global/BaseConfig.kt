package com.lyentech.common.global

/**
 * @author by jason-何伟杰，2022/3/8
 * des:全架构通用配置参数
 */
object BaseConfig {

    const val DATA_APP_TOKEN = "DATA_APP_TOKEN"
    const val DATA_RANDOM_MAC = "DATA_RANDOM_MAC"

    const val LOAD_SIZE_IN_PAGE = "10"
    const val LOAD_SIZE_IN_LIST = 10
    const val LOAD_START_PAGE = 0

    const val CODE_BACK_LOGIN = 0X71
    const val CODE_HTTP_ID_PERMISSION = 5005
    const val CODE_SUC = 0X23
    const val CODE_ERR = 0X24
}
