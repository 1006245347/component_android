package com.lyentech.common.global

class HttpListResponse<T> {
    var select: MutableList<T>? = null

    var pagination: PageCount? = null

    class PageCount {
        var totalCount = 0
        var pageCount = 0

    }
}