package com.lyentech.common.listener;

public interface PageListener {
    public int mCurPage=0;

    void a();
}
