package com.lyentech.common.utils

/**
 * @author jason-何伟杰，2020-07-04
 * des:
 */
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.text.TextUtils
import java.io.*
import java.nio.channels.FileChannel
import java.util.*

object FileUtils {

    val ROOT_DIR = "Android/data/" + UIhelper.getPackageName()
    val DOWNLOAD_DIR = "download"
    val CACHE_DIR = "cache"
    val ICON_DIR = "icon"

    val APP_STORAGE_ROOT = "jason_community"

    /**
     * 判断SD卡是否挂载
     */
    val isSDCardAvailable: Boolean
        get() = Environment.MEDIA_MOUNTED == Environment
            .getExternalStorageState()

    /**
     * 获取下载目录
     */
    val downloadDir: String?
        get() = getDir(DOWNLOAD_DIR)

    /**
     * 获取缓存目录
     */
    val cacheDir: String?
        get() = getDir(CACHE_DIR)

    /**
     * 获取icon目录
     */
    val iconDir: String?
        get() = getDir(ICON_DIR)

    /**
     * 获取SD下的应用目录
     */
    val externalStoragePath: String
        get() {
            val sb = StringBuilder()
            sb.append(Environment.getExternalStorageDirectory().absolutePath)
            sb.append(File.separator)
            sb.append(ROOT_DIR)
            sb.append(File.separator)
            return sb.toString()
        }

    /**
     * 获取SD下当前APP的目录
     */
    val appExternalStoragePath: String
        get() {
            val sb = StringBuilder()
            sb.append(Environment.getExternalStorageDirectory().absolutePath)//妈的，是系统跟目录，不是/storage/
            sb.append(File.separator)
            sb.append(APP_STORAGE_ROOT)
            sb.append(File.separator)
            return sb.toString()
        }

    /**
     * 获取应用的cache目录
     */
    val cachePath: String?
        get() {
            val f = UIhelper.getContext().cacheDir
            return if (null == f) {
                null
            } else {
                f.absolutePath + "/"
            }
        }

    /**
     * 获取应用目录，当SD卡存在时，获取SD卡上的目录，当SD卡不存在时，获取应用的cache目录
     */
    fun getDir(name: String): String? {
        val sb = StringBuilder()
        if (isSDCardAvailable) {
            sb.append(appExternalStoragePath)
        } else {
            sb.append(cachePath)
        }
        sb.append(name)
        sb.append(File.separator)
        val path = sb.toString()
        return if (createDirs(path)) {
            path
        } else {
            null
        }
    }

    /**
     * 创建文件夹
     */
    fun createDirs(dirPath: String): Boolean {
        val file = File(dirPath)
        return if (!file.exists() || !file.isDirectory) {
            file.mkdirs()
        } else true
    }

    /**
     * 产生图片的路径，这里是在缓存目录下
     */
    fun generateImgePathInStoragePath(): String {
        return getDir(ICON_DIR) + System.currentTimeMillis().toString() + ".jpg"
    }

    /**
     * 发起剪裁图片的请求
     *
     * @param activity    上下文
     * @param srcFile     原文件的File
     * @param output      输出文件的File
     * @param requestCode 请求码
     */
    fun startPhotoZoom(activity: Activity, srcFile: File, output: File, requestCode: Int) {
        val intent = Intent("com.android.camera.action.CROP")
        intent.setDataAndType(getImageContentUri(activity, srcFile), "image/*")
        // crop为true是设置在开启的intent中设置显示的view可以剪裁
        intent.putExtra("crop", "true")

        // aspectX aspectY 是宽高的比例
        intent.putExtra("aspectX", 1)
        intent.putExtra("aspectY", 1)

        // outputX,outputY 是剪裁图片的宽高
        intent.putExtra("outputX", 800)
        intent.putExtra("outputY", 480)
        // intent.putExtra("return-data", false);

        //        intent.putExtra(MediaStore.EXTRA_OUTPUT,
        //                Uri.fromFile(new File(FileUtils.picPath)));

        intent.putExtra("return-data", false)// true:不返回uri，false：返回uri
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(output))
        intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString())
        // intent.putExtra("noFaceDetection", true); // no face detection

        activity.startActivityForResult(intent, requestCode)
    }

    /**
     * 安卓7.0裁剪根据文件路径获取uri
     */
    fun getImageContentUri(context: Context, imageFile: File): Uri? {
        val filePath = imageFile.absolutePath
        val cursor = context.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Images.Media._ID),
            MediaStore.Images.Media.DATA + "=? ",
            arrayOf(filePath), null
        )

        if (cursor != null && cursor.moveToFirst()) {
            val id = cursor.getInt(
                cursor
                    .getColumnIndex(MediaStore.MediaColumns._ID)
            )
            val baseUri = Uri.parse("content://media/external/images/media")
            return Uri.withAppendedPath(baseUri, "" + id)
        } else {
            if (imageFile.exists()) {
                val values = ContentValues()
                values.put(MediaStore.Images.Media.DATA, filePath)
                return context.contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
                )
            } else {
                return null
            }
        }
    }

    /**
     * 复制bm
     *
     * @param bm
     * @return
     */
    fun saveBitmap(bm: Bitmap): String {
        var croppath = ""
        try {
            val f = File(generateImgePathInStoragePath())
            //得到相机图片存到本地的图片
            croppath = f.path
            if (f.exists()) {
                f.delete()
            }
            val out = FileOutputStream(f)
            bm.compress(Bitmap.CompressFormat.JPEG, 100, out)
            out.flush()
            out.close()
        } catch (e: FileNotFoundException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }

        return croppath
    }

    /**
     * 按质量压缩bm
     *
     * @param bm
     * @param quality 压缩率
     * @return
     */
    fun saveBitmapByQuality(bm: Bitmap, quality: Int): String {
        var croppath = ""
        try {
            val f = File(generateImgePathInStoragePath())
            //得到相机图片存到本地的图片
            croppath = f.path
            if (f.exists()) {
                f.delete()
            }
            val out = FileOutputStream(f)
            bm.compress(Bitmap.CompressFormat.JPEG, quality, out)
            out.flush()
            out.close()
        } catch (e: FileNotFoundException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }

        return croppath
    }

    @Throws(IOException::class)
    fun copy(src: File, dst: File) {
        val inStream = FileInputStream(src)
        val outStream = FileOutputStream(dst)
        val inChannel = inStream.channel
        val outChannel = outStream.channel
        inChannel.transferTo(0L, inChannel.size(), outChannel)
        inStream.close()
        outStream.close()
    }

    /**
     * 根据图片文件类型获取图片文件的后缀名
     *
     * @param filePath
     * @return
     */
    fun getImageFileExt(filePath: String): String {
        val mFileTypes = HashMap<String, String>()
        mFileTypes["FFD8FF"] = ".jpg"
        mFileTypes["89504E47"] = ".png"
        mFileTypes["474946"] = ".gif"
        mFileTypes["49492A00"] = ".tif"
        mFileTypes["424D"] = ".bmp"

        val value = mFileTypes[getFileHeader(filePath)]
        val ext = if (TextUtils.isEmpty(value)) ".jpg" else value
        return ""+ext
    }

    /**
     * 获取文件头信息
     *
     * @param filePath
     * @return
     */
    @JvmStatic
    fun getFileHeader(filePath: String): String? {
        var `is`: FileInputStream? = null
        var value: String? = null
        try {
            `is` = FileInputStream(filePath)
            val b = ByteArray(3)
            `is`.read(b, 0, b.size)
            value = bytesToHexString(b)
        } catch (e: Exception) {
        } finally {
            if (null != `is`) {
                try {
                    `is`.close()
                } catch (e: IOException) {
                }

            }
        }
        return value
    }

    /**
     * 将byte字节转换为十六进制字符串
     *
     * @param src
     * @return
     */
    @JvmStatic
    private fun bytesToHexString(src: ByteArray?): String? {
        val builder = StringBuilder()
        if (src == null || src.isEmpty()) {
            return null
        }
        var hv: String
        for (i in src.indices) {
            hv = Integer.toHexString(src[i].toInt() and 0xFF).toUpperCase()
            if (hv.length < 2) {
                builder.append(0)
            }
            builder.append(hv)
        }
        val header = builder.toString()
        return header
    }

    @JvmStatic
    fun delete(f: File) {
        val b = f.listFiles() ?: return
        for (i in b.indices) {
            if (b[i].isFile) {
                b[i].delete()
            } else {
                delete(b[i])
            }
        }
        f.delete()
    }

    //复制文件
    @JvmStatic
    fun copyFileOrDirectory(srcDir: String?, dstDir: String?) {
        try {
            val src = File(srcDir)
            val dst = File(dstDir, src.name)
            if (src.isDirectory) {
                val files = src.list()
                val filesLength = files.size
                for (i in 0 until filesLength) {
                    val src1 = File(src, files[i]).path
                    val dst1 = dst.path
                    copyFileOrDirectory(src1, dst1)
                }
            } else {
                copyFile(src, dst)
            }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    @JvmStatic
    @Throws(IOException::class)
    fun copyFile(sourceFile: File?, destFile: File) {
        if (!destFile.parentFile.exists()) destFile.parentFile.mkdirs()
        if (!destFile.exists()) {
            destFile.createNewFile()
        }
        var source: FileChannel? = null
        var destination: FileChannel? = null
        try {
            source = FileInputStream(sourceFile).channel
            destination = FileOutputStream(destFile).channel
            destination.transferFrom(source, 0, source.size())
        } finally {
            if (source != null) {
                source.close()
            }
            if (destination != null) {
                destination.close()
            }
        }
    }
}
