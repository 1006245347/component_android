package com.lyentech.common.listener

/**
 * @author by jason-何伟杰，2022/3/9
 * des:全局通用Event事件,为了每个组件都通用，des字段是个json文本
 */
class ModuleEvent {
    var key: String = "module_name"
    var des: String = "json"

    public constructor(key: String, des: String) {
        this.key = key
        this.des = des
    }
}