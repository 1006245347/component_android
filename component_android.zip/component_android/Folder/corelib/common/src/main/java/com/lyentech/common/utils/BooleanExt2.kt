package com.zh.xmindeasy.utils

/**
 * @author jason-何伟杰，2020-02-17
 * des:(3<2).otherwise{}.yes{}
 */
sealed class BooleanExt2<out T>////起桥梁作用的中间类，定义成协变

object Yes : BooleanExt2<Nothing>()//Nothing是所有类型的子类型，协变的类继承关系和泛型参数类型继承关系一致

class TransferData2<T>(val data: T) : BooleanExt2<T>()//data只涉及到了只读的操作

//声明成inline函数
inline fun <T> Boolean.otherwise(block: () -> T): BooleanExt2<T> = when {
    !this -> {
        TransferData2(block.invoke())
    }
    else -> Yes
}

inline fun <T> BooleanExt2<T>.yes(block: () -> T): T = when (this) {
    is Yes ->
        block()
    is TransferData2 ->
        this.data
}