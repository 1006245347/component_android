package com.lyentech.route

/**
 * @author by jason-何伟杰，2022/3/9
 * des:路由表
 */
object ARouterPath {

    //项目的组件
    const val MODULE_MAIN = "/main/"
    const val MODULE_UPLOAD = "/upload/"

    //项目组件下的路由路径
    const val MAIN_LAUNCH = MODULE_MAIN + "launch" //闪屏页
    const val MAIN_LOGIN = MODULE_MAIN + "login"//登录页

    const val UPLOAD_LIST = MODULE_UPLOAD + "list"//视频页
}