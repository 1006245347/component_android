package com.lyentech.main.mmvm

import com.lyentech.common.base.BaseGVm

class LoginMVm : BaseGVm() {

}