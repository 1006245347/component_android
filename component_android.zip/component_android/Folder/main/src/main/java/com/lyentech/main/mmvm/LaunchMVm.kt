package com.lyentech.main.mmvm

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.lyentech.common.base.BaseGVm
import com.lyentech.common.global.GlobalCode
import com.lyentech.common.http.RetrofitFactory
import com.lyentech.main.api.ApiUrl
import kotlinx.coroutines.delay
import java.util.*

/**
 * @author by jason-何伟杰，2022/3/10
 * des:首页业务数据处理
 */
class LaunchMVm : BaseGVm() {

    val mockObs = MutableLiveData<String>()
    fun getMockTest() {
        launchSub {
            delay(2000)
            val result = RetrofitFactory.doGetRequest(ApiUrl.MOCK_LOGIN2)
            mockObs.postValue(result)//子线程下用postValue
        }
    }

    fun doMock(): LiveData<String> = execute {
        RetrofitFactory.doGetRequest(ApiUrl.MOCK_LOGIN)+""
        ""
    }

    fun doMock2():LiveData<String> =executeSub {
        RetrofitFactory.doGetRequest(ApiUrl.MOCK_LOGIN)+""
    }


}