package com.lyentech.main.global

import com.alibaba.android.arouter.launcher.ARouter
import com.lyentech.common.global.ApplicationProvider
import com.lyentech.common.global.BaseModuleInit

class ModuleInitMain : BaseModuleInit() {
    override fun onCreate() {
        super.onCreate()
        ARouter.openDebug()
        ARouter.openLog()
        ARouter.init(ApplicationProvider.appContext)
    }

    override val priority: Int
        get() = 0
}