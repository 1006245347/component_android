package com.lyentech.main.api

object ApiUrl {

    const val MOCK_LOGIN =
        "http://miraclegenesis.cn/padsales/UserLogin.ashx?AppName=cateringSalesPadFast&Plateform=PAD&Version=1.2.1&UserID=1000&DeviceCode=1fb3cc66c42ccc03&usernb=1000&password=670b14728ad9902aecba32e22fa4f6bd"
    const val MOCK_LOGIN2 =
        "https://venus.leayun.cn/venus/api/ahtena/device/cloudShelfHome?deviceUniqueId=F4911E69986F"

}