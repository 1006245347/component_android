package com.lyentech.main.ui

import com.alibaba.android.arouter.facade.annotation.Route
import com.lyentech.common.base.BaseGActivity
import com.lyentech.common.global.GlobalCode
import com.lyentech.common.utils.ToastUtil
import com.lyentech.common.utils.UIhelper.clickFilter
import com.lyentech.common.widget.pic.GlideApp
import com.lyentech.main.R
import com.lyentech.main.mmvm.LaunchMVm
import com.lyentech.route.ARouterPath
import kotlinx.android.synthetic.main.activity_launch.*

@Route(path = ARouterPath.MAIN_LAUNCH)
class LaunchActivity : BaseGActivity() {

    private val launchMVm = createViewModel(LaunchMVm()) as LaunchMVm
    override fun initAty() {

        //        EventBus.getDefault().register(this)
//        val json = "{\"time\":\"123\"}"
//        EventBus.getDefault().post(ModuleEvent("main", json))

        loadImg()
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_launch
    }

    val imgUrl =
        "https://jzhc-zhwl.oss-cn-huhehaote.aliyuncs.com/e6yun/e6yun3/driverInfoKey/tmp_56a59f7705d6574be26db79d8b98ffaf19b08fe538521aa2.jpg"

    private fun loadImg() {
        GlideApp.with(this).load(imgUrl).into(ivc1)
        GlobalCode.printLog("gvm=" + mViewModel)
        GlobalCode.printLog("lvm=" + launchMVm)
        launchMVm.delayMain({
            ToastUtil.showToast("delay_toast>>" + launchMVm.loadState)
        }, 4000)

        //数据响应回调
        launchMVm.mockObs.observe(this, {
//            GlobalCode.printLog("callback>>$it")
        })

        //模拟数据请求
//        launchMVm.getMockTest()

        //模拟数据请求
        launchMVm.doMock2().observe(this, {
            GlobalCode.printLog("execute2>>$it")
        })

        btnc1.clickFilter {
            launchMVm.cancel()
        }
    }
}
