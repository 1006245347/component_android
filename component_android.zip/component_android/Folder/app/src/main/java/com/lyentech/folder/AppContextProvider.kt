package com.lyentech.folder

import com.alibaba.android.arouter.launcher.ARouter
import com.lyentech.common.global.ApplicationProvider
import com.lyentech.common.global.ModuleInitDelegate
import com.lyentech.main.global.ModuleInitMain
import com.lyentech.upload.global.ModuleInitUpload
/**
 * @author by jason-何伟杰，2022/3/9
 * des:集成模式，将所有组件
 *
 * 不足，非集成模式下-app库无法获取到组件的依赖类。。会报错的，不打集成包直接注释就行
 */
class AppContextProvider : ApplicationProvider() {
    init {
        ModuleInitDelegate.register(ModuleInitMain(), ModuleInitUpload())
    }

    override fun onCreate() {
        super.onCreate()
    }

    override fun onTerminate() {
        super.onTerminate()
        ARouter.getInstance().destroy()
    }
}